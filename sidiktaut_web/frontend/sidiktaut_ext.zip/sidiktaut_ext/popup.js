document.addEventListener('DOMContentLoaded', async () => {
    const urlInput = document.getElementById('urlInput');
    const scanBtn = document.getElementById('scanBtn');
    const resultArea = document.getElementById('resultArea');
    const scoreText = document.getElementById('scoreText');
    const verdictText = document.getElementById('verdictText');
    const errorMsg = document.getElementById('errorMsg');
    const statusBadge = document.getElementById('statusBadge');
  
    // 1. Ambil URL dari Tab Aktif otomatis
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab && tab.url) {
      urlInput.value = tab.url;
    }
  
    // 2. Fungsi Scan
    scanBtn.addEventListener('click', async () => {
      const targetUrl = urlInput.value;
      if (!targetUrl) return;
  
      // Reset tampilan
      scanBtn.disabled = true;
      scanBtn.innerText = "Scanning...";
      errorMsg.classList.add('hidden');
      resultArea.classList.add('hidden');
      statusBadge.innerText = "Checking...";
      statusBadge.style.color = "#FFD60A";
  
      try {
        // NEMBAK KE BACKEND FLASK LOKAL
        const response = await fetch('http://127.0.0.1:5000/scan', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ url: targetUrl })
        });
  
        const data = await response.json();
  
        // Tampilkan Hasil
        resultArea.classList.remove('hidden');
        scoreText.innerText = data.malicious;
        
        // Logic Warna & Teks
        if (data.malicious > 0) {
            verdictText.innerText = "⚠️ BERBAHAYA / MALICIOUS";
            verdictText.style.color = "#FF3B30"; // Merah
            scoreText.style.color = "#FF3B30";
        } else {
            verdictText.innerText = "✅ AMAN / SAFE";
            verdictText.style.color = "#34C759"; // Hijau
            scoreText.style.color = "#34C759";
        }

        statusBadge.innerText = "Done";
        statusBadge.style.color = "#34C759";
  
      } catch (err) {
        // Kalau Backend Mati / Error
        console.error(err);
        errorMsg.innerText = "Gagal connect ke Localhost:5000. Pastikan Backend Python nyala!";
        errorMsg.classList.remove('hidden');
        statusBadge.innerText = "Error";
        statusBadge.style.color = "#FF3B30";
      } finally {
        scanBtn.disabled = false;
        scanBtn.innerText = "SCAN SEKARANG";
      }
    });
  });