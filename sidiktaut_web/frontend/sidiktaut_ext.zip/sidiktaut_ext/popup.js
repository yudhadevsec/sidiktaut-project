document.addEventListener('DOMContentLoaded', async () => {
    // 1. Ambil URL dari Tab Aktif
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    const currentUrl = tab.url;
    
    document.getElementById('currentUrl').innerText = currentUrl;

    // 2. Event Listener Tombol Scan
    const btn = document.getElementById('scanBtn');
    btn.addEventListener('click', async () => {
        // UI Loading State
        btn.innerText = "MENGANALISIS...";
        btn.disabled = true;
        document.getElementById('resultArea').classList.add('hidden');
        document.getElementById('errorArea').classList.add('hidden');

        try {
            // 3. Tembak ke Backend Flask Localhost
            // Pastikan Flask app.py sudah RUNNING!
            const response = await fetch('http://127.0.0.1:5000/scan', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ url: currentUrl })
            });

            const data = await response.json();

            if (response.ok) {
                // Tampilkan Data
                document.getElementById('malicious').innerText = data.malicious;
                document.getElementById('safe').innerText = data.harmless;
                
                const verdict = document.getElementById('verdict');
                if (data.malicious > 0) {
                    verdict.innerText = "⚠️ HATI-HATI! Link ini terindikasi berbahaya.";
                    verdict.style.color = "#ef4444";
                } else {
                    verdict.innerText = "✅ Link terlihat aman.";
                    verdict.style.color = "#10b981";
                }
                
                document.getElementById('resultArea').classList.remove('hidden');
            } else {
                throw new Error(data.error || "Gagal scan url.");
            }

        } catch (err) {
            const errorDiv = document.getElementById('errorArea');
            errorDiv.innerHTML = `Gagal terhubung ke SidikTaut Core.<br>Pastikan backend (app.py) sudah jalan!`;
            errorDiv.classList.remove('hidden');
        } finally {
            btn.innerText = "SCAN SEKARANG";
            btn.disabled = false;
        }
    });
});
