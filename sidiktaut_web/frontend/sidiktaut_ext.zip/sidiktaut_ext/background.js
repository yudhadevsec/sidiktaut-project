// Pas extension diinstall, bikin menu klik kanan
chrome.runtime.onInstalled.addListener(() => {
    chrome.contextMenus.create({
      id: "sidiktaut_quick_scan",
      title: "🛡️ Scan Page with SidikTaut",
      contexts: ["page", "link"]
    });
  });
  
  // Pas menu diklik
  chrome.contextMenus.onClicked.addListener((info, tab) => {
    if (info.menuItemId === "sidiktaut_quick_scan") {
      
      // Ambil URL (entah link yang diklik, atau halaman yang lagi dibuka)
      const targetUrl = info.linkUrl || info.pageUrl;
      
      // Kirim Notifikasi Native "Mulai Scan"
      chrome.notifications.create({
        type: "basic",
        iconUrl: "icon.png",
        title: "SidikTaut Intelligence",
        message: `Memulai scan: ${targetUrl}`
      });
  
      // Kirim data ke backend (Background process)
      fetch('http://127.0.0.1:5000/scan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: targetUrl })
      })
      .then(res => res.json())
      .then(data => {
        // Notifikasi Hasil
        const isSafe = data.malicious === 0;
        chrome.notifications.create({
          type: "basic",
          iconUrl: "icon.png",
          title: isSafe ? "✅ LINK AMAN" : "⚠️ LINK BERBAHAYA",
          message: `Malicious: ${data.malicious}, Suspicious: ${data.suspicious}. Klik untuk detail.`
        });
      })
      .catch(err => {
        chrome.notifications.create({
            type: "basic",
            iconUrl: "icon.png",
            title: "❌ Gagal Koneksi",
            message: "Pastikan backend python (app.py) menyala!"
        });
      });
    }
  });